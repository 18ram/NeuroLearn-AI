import { useState, useEffect } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut, User } from 'firebase/auth';
import { doc, getDoc, setDoc, collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { auth, db, googleProvider } from './firebase';
import { UserProfile, DocumentMetadata, Progress } from './types';
import { 
  LayoutDashboard, 
  FileText, 
  BrainCircuit, 
  Layers, 
  LogOut, 
  LogIn, 
  PlusCircle,
  TrendingUp,
  BookOpen,
  Trophy,
  Loader2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// Components
import Dashboard from './components/Dashboard';
import DocumentUpload from './components/DocumentUpload';
import DocumentList from './components/DocumentList';
import QuizView from './components/QuizView';
import FlashcardView from './components/FlashcardView';
import SummaryView from './components/SummaryView';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'documents' | 'quizzes' | 'flashcards'>('dashboard');
  const [documents, setDocuments] = useState<DocumentMetadata[]>([]);
  const [progress, setProgress] = useState<Progress[]>([]);
  const [selectedDoc, setSelectedDoc] = useState<DocumentMetadata | null>(null);
  const [viewMode, setViewMode] = useState<'list' | 'summary' | 'quiz' | 'flashcards'>('list');

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        const userDocRef = doc(db, 'users', firebaseUser.uid);
        const userDoc = await getDoc(userDocRef);
        
        if (!userDoc.exists()) {
          const newProfile: UserProfile = {
            uid: firebaseUser.uid,
            displayName: firebaseUser.displayName,
            email: firebaseUser.email,
            photoURL: firebaseUser.photoURL,
            createdAt: new Date().toISOString(),
          };
          await setDoc(userDocRef, newProfile);
          setProfile(newProfile);
        } else {
          setProfile(userDoc.data() as UserProfile);
        }

        // Listen for documents
        const docsQuery = query(collection(db, 'users', firebaseUser.uid, 'documents'), orderBy('createdAt', 'desc'));
        onSnapshot(docsQuery, (snapshot) => {
          setDocuments(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as DocumentMetadata)));
        });

        // Listen for progress
        const progressQuery = query(collection(db, 'users', firebaseUser.uid, 'progress'), orderBy('timestamp', 'desc'));
        onSnapshot(progressQuery, (snapshot) => {
          setProgress(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Progress)));
        });
      } else {
        setProfile(null);
        setDocuments([]);
        setProgress([]);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error('Login failed:', error);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setActiveTab('dashboard');
      setViewMode('list');
      setSelectedDoc(null);
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-stone-50 flex flex-col items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full bg-white rounded-3xl shadow-xl p-8 text-center border border-black/5"
        >
          <div className="w-16 h-16 bg-emerald-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <BrainCircuit className="w-8 h-8 text-emerald-600" />
          </div>
          <h1 className="text-3xl font-bold text-stone-900 mb-2 font-sans tracking-tight">NeuroLearn AI</h1>
          <p className="text-stone-500 mb-8">Your intelligent companion for accelerated learning and document mastery.</p>
          <button
            onClick={handleLogin}
            className="w-full py-4 px-6 bg-stone-900 text-white rounded-2xl font-medium flex items-center justify-center gap-3 hover:bg-stone-800 transition-colors shadow-lg"
          >
            <LogIn className="w-5 h-5" />
            Sign in with Google
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-50 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-black/5 flex flex-col">
        <div className="p-6 flex items-center gap-3 border-b border-black/5">
          <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
            <BrainCircuit className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-stone-900 tracking-tight">NeuroLearn</span>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          <SidebarItem 
            icon={<LayoutDashboard />} 
            label="Dashboard" 
            active={activeTab === 'dashboard'} 
            onClick={() => { setActiveTab('dashboard'); setViewMode('list'); setSelectedDoc(null); }} 
          />
          <SidebarItem 
            icon={<FileText />} 
            label="Documents" 
            active={activeTab === 'documents'} 
            onClick={() => { setActiveTab('documents'); setViewMode('list'); setSelectedDoc(null); }} 
          />
          <SidebarItem 
            icon={<BrainCircuit />} 
            label="Quizzes" 
            active={activeTab === 'quizzes'} 
            onClick={() => { setActiveTab('quizzes'); setViewMode('list'); setSelectedDoc(null); }} 
          />
          <SidebarItem 
            icon={<Layers />} 
            label="Flashcards" 
            active={activeTab === 'flashcards'} 
            onClick={() => { setActiveTab('flashcards'); setViewMode('list'); setSelectedDoc(null); }} 
          />
        </nav>

        <div className="p-4 border-t border-black/5">
          <div className="flex items-center gap-3 p-3 rounded-2xl bg-stone-50 mb-4">
            <img 
              src={profile?.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${profile?.uid}`} 
              alt="Avatar" 
              className="w-10 h-10 rounded-xl"
              referrerPolicy="no-referrer"
            />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-stone-900 truncate">{profile?.displayName}</p>
              <p className="text-xs text-stone-500 truncate">{profile?.email}</p>
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="w-full flex items-center gap-3 p-3 text-stone-500 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all"
          >
            <LogOut className="w-5 h-5" />
            <span className="text-sm font-medium">Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        <header className="h-20 bg-white border-b border-black/5 flex items-center justify-between px-8 sticky top-0 z-10">
          <h2 className="text-xl font-bold text-stone-900 capitalize font-sans tracking-tight">
            {activeTab}
          </h2>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-4 py-2 bg-emerald-50 text-emerald-700 rounded-full text-sm font-medium">
              <Trophy className="w-4 h-4" />
              <span>{progress.length} Learning Sessions</span>
            </div>
          </div>
        </header>

        <div className="p-8 max-w-7xl mx-auto">
          <AnimatePresence mode="wait">
            {activeTab === 'dashboard' && (
              <motion.div 
                key="dashboard"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                <Dashboard progress={progress} documents={documents} />
              </motion.div>
            )}

            {activeTab === 'documents' && (
              <motion.div 
                key="documents"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                {viewMode === 'list' ? (
                  <div className="space-y-8">
                    <DocumentUpload userId={user.uid} />
                    <DocumentList 
                      documents={documents} 
                      userId={user.uid}
                      onSelect={(doc) => { setSelectedDoc(doc); setViewMode('summary'); }} 
                    />
                  </div>
                ) : (
                  <SummaryView 
                    doc={selectedDoc!} 
                    onBack={() => setViewMode('list')} 
                    onStartQuiz={() => { setViewMode('quiz'); setActiveTab('quizzes'); }}
                    onStartFlashcards={() => { setViewMode('flashcards'); setActiveTab('flashcards'); }}
                  />
                )}
              </motion.div>
            )}

            {activeTab === 'quizzes' && (
              <motion.div 
                key="quizzes"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                {viewMode === 'quiz' && selectedDoc ? (
                  <QuizView 
                    doc={selectedDoc} 
                    userId={user.uid}
                    onComplete={() => { setViewMode('list'); setActiveTab('dashboard'); }} 
                    onBack={() => setViewMode('list')}
                  />
                ) : (
                  <div className="text-center py-20 bg-white rounded-3xl border border-black/5 shadow-sm">
                    <BrainCircuit className="w-16 h-16 text-stone-200 mx-auto mb-4" />
                    <h3 className="text-xl font-bold text-stone-900 mb-2">Ready to test your knowledge?</h3>
                    <p className="text-stone-500 mb-6">Select a document from the Documents tab to generate a quiz.</p>
                    <button 
                      onClick={() => setActiveTab('documents')}
                      className="px-6 py-3 bg-stone-900 text-white rounded-2xl font-medium hover:bg-stone-800 transition-colors"
                    >
                      Go to Documents
                    </button>
                  </div>
                )}
              </motion.div>
            )}

            {activeTab === 'flashcards' && (
              <motion.div 
                key="flashcards"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                {viewMode === 'flashcards' && selectedDoc ? (
                  <FlashcardView 
                    doc={selectedDoc} 
                    userId={user.uid}
                    onBack={() => setViewMode('list')}
                  />
                ) : (
                  <div className="text-center py-20 bg-white rounded-3xl border border-black/5 shadow-sm">
                    <Layers className="w-16 h-16 text-stone-200 mx-auto mb-4" />
                    <h3 className="text-xl font-bold text-stone-900 mb-2">Master concepts with flashcards</h3>
                    <p className="text-stone-500 mb-6">Select a document from the Documents tab to study flashcards.</p>
                    <button 
                      onClick={() => setActiveTab('documents')}
                      className="px-6 py-3 bg-stone-900 text-white rounded-2xl font-medium hover:bg-stone-800 transition-colors"
                    >
                      Go to Documents
                    </button>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}

function SidebarItem({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active?: boolean, onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-3 p-3 rounded-2xl transition-all font-medium text-sm",
        active 
          ? "bg-emerald-50 text-emerald-700 shadow-sm border border-emerald-100/50" 
          : "text-stone-500 hover:text-stone-900 hover:bg-stone-100"
      )}
    >
      <span className={cn("w-5 h-5", active ? "text-emerald-600" : "text-stone-400")}>
        {icon}
      </span>
      {label}
    </button>
  );
}
