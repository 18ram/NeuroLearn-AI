import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export const generateSummary = async (content: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Summarize the following educational content in a structured way with key points and a detailed explanation:\n\n${content}`,
    config: {
      systemInstruction: "You are an expert academic tutor. Provide summaries that are clear, concise, and highlight essential concepts for students.",
    },
  });
  return response.text;
};

export const generateQuiz = async (content: string, difficulty: 'easy' | 'medium' | 'hard') => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Generate a ${difficulty} difficulty quiz based on this content. Include 5 questions. Each question should have a question, options (for MCQ), and a correct answer. Use a mix of MCQ, True/False, and Fill in the blanks.\n\nContent:\n${content}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            question: { type: Type.STRING },
            options: { type: Type.ARRAY, items: { type: Type.STRING } },
            correctAnswer: { type: Type.STRING },
            type: { type: Type.STRING, enum: ["mcq", "tf", "fill"] }
          },
          required: ["question", "correctAnswer", "type"]
        }
      }
    },
  });
  return JSON.parse(response.text);
};

export const generateFlashcards = async (content: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Generate 10 flashcards (Question on front, Answer on back) from the following content:\n\n${content}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            front: { type: Type.STRING },
            back: { type: Type.STRING }
          },
          required: ["front", "back"]
        }
      }
    },
  });
  return JSON.parse(response.text);
};

export const generateKeyTerms = async (content: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Extract the top 10 most important key terms and their brief definitions from the following content:\n\n${content}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.STRING
        }
      }
    },
  });
  return JSON.parse(response.text);
};
