export interface UserProfile {
  uid: string;
  displayName: string | null;
  email: string | null;
  photoURL: string | null;
  createdAt: string;
}

export interface DocumentMetadata {
  id: string;
  title: string;
  content: string;
  summary: string;
  keyTerms?: string[];
  createdAt: string;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswer: string;
  type: 'mcq' | 'tf' | 'fill';
}

export interface Quiz {
  id: string;
  questions: QuizQuestion[];
  difficulty: 'easy' | 'medium' | 'hard';
  createdAt: string;
}

export interface Flashcard {
  id: string;
  front: string;
  back: string;
  nextReview: string;
  interval: number;
  easeFactor: number;
}

export interface Progress {
  id: string;
  type: 'quiz' | 'flashcards';
  docId: string;
  quizId?: string;
  score: number;
  totalQuestions: number;
  timestamp: string;
}
