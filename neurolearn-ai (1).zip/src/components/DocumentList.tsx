import { DocumentMetadata } from '../types';
import { FileText, ChevronRight, Clock, Trash2 } from 'lucide-react';
import { motion } from 'motion/react';
import { doc, deleteDoc } from 'firebase/firestore';
import { db } from '../firebase';

interface DocumentListProps {
  documents: DocumentMetadata[];
  userId: string;
  onSelect: (doc: DocumentMetadata) => void;
}

export default function DocumentList({ documents, userId, onSelect }: DocumentListProps) {
  const handleDelete = async (e: React.MouseEvent, docId: string) => {
    e.stopPropagation();
    if (window.confirm('Are you sure you want to delete this document?')) {
      try {
        await deleteDoc(doc(db, 'users', userId, 'documents', docId));
      } catch (error) {
        console.error('Delete failed:', error);
      }
    }
  };

  if (documents.length === 0) {
    return (
      <div className="text-center py-20 bg-white rounded-3xl border border-black/5 shadow-sm">
        <FileText className="w-16 h-16 text-stone-200 mx-auto mb-4" />
        <h3 className="text-xl font-bold text-stone-900 mb-2">No documents yet</h3>
        <p className="text-stone-500">Upload your first document to start learning.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-bold text-stone-900 px-2">Your Documents</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {documents.map((doc, index) => (
          <motion.div
            key={doc.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.05 }}
            onClick={() => onSelect(doc)}
            className="group bg-white p-6 rounded-3xl border border-black/5 shadow-sm hover:shadow-md hover:border-emerald-200 transition-all cursor-pointer relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 p-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
              <button 
                onClick={(e) => handleDelete(e, doc.id)}
                className="p-2 bg-red-50 text-red-600 rounded-xl hover:bg-red-100 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>
              <div className="p-2">
                <ChevronRight className="w-5 h-5 text-emerald-600" />
              </div>
            </div>
            
            <div className="w-12 h-12 bg-stone-50 group-hover:bg-emerald-50 rounded-2xl flex items-center justify-center mb-4 transition-colors">
              <FileText className="w-6 h-6 text-stone-400 group-hover:text-emerald-600" />
            </div>
            
            <h4 className="font-bold text-stone-900 mb-2 line-clamp-1">{doc.title}</h4>
            <p className="text-sm text-stone-500 line-clamp-2 mb-4">{doc.summary.substring(0, 100)}...</p>
            
            <div className="flex items-center gap-2 text-xs text-stone-400">
              <Clock className="w-3 h-3" />
              {new Date(doc.createdAt).toLocaleDateString()}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
