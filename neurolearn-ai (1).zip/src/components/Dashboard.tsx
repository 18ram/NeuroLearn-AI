import { Progress, DocumentMetadata } from '../types';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area
} from 'recharts';
import { BookOpen, BrainCircuit, Clock, Trophy, Layers } from 'lucide-react';

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}

interface DashboardProps {
  progress: Progress[];
  documents: DocumentMetadata[];
}

export default function Dashboard({ progress, documents }: DashboardProps) {
  // Calculate average score (only for quizzes)
  const quizSessions = progress.filter(p => p.type === 'quiz');
  const averageScore = quizSessions.length > 0 
    ? Math.round(quizSessions.reduce((acc, curr) => acc + (curr.score / curr.totalQuestions) * 100, 0) / quizSessions.length)
    : 0;

  // Calculate streak
  const calculateStreak = (sessions: Progress[]) => {
    if (sessions.length === 0) return 0;
    
    const dates = sessions.map(s => new Date(s.timestamp).toDateString());
    const uniqueDates = Array.from(new Set(dates)).map(d => new Date(d));
    uniqueDates.sort((a, b) => b.getTime() - a.getTime());

    let streak = 0;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    let lastDate = uniqueDates[0];
    const diffDays = Math.floor((today.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffDays > 1) return 0; // Streak broken

    streak = 1;
    for (let i = 1; i < uniqueDates.length; i++) {
      const prevDate = uniqueDates[i-1];
      const currDate = uniqueDates[i];
      const diff = Math.floor((prevDate.getTime() - currDate.getTime()) / (1000 * 60 * 60 * 24));
      
      if (diff === 1) {
        streak++;
      } else {
        break;
      }
    }
    
    return streak;
  };

  const streak = calculateStreak(progress);

  const chartData = progress
    .filter(p => p.type === 'quiz')
    .slice(0, 7)
    .reverse()
    .map(p => ({
      date: new Date(p.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
      score: Math.round((p.score / p.totalQuestions) * 100)
    }));

  return (
    <div className="space-y-8">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          icon={<BookOpen className="text-blue-600" />} 
          label="Documents" 
          value={documents.length} 
          sublabel="Total uploaded"
        />
        <StatCard 
          icon={<BrainCircuit className="text-purple-600" />} 
          label="Sessions" 
          value={progress.length} 
          sublabel="Total completed"
        />
        <StatCard 
          icon={<Trophy className="text-amber-600" />} 
          label="Avg. Score" 
          value={`${averageScore}%`} 
          sublabel="Quiz performance"
        />
        <StatCard 
          icon={<Clock className="text-emerald-600" />} 
          label="Streak" 
          value={`${streak} Days`} 
          sublabel="Learning consistency"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Performance Chart */}
        <div className="bg-white p-8 rounded-3xl border border-black/5 shadow-sm">
          <h3 className="text-lg font-bold text-stone-900 mb-6">Performance Trend</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f1f1" />
                <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#888' }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#888' }} domain={[0, 100]} />
                <Tooltip 
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Area type="monotone" dataKey="score" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorScore)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white p-8 rounded-3xl border border-black/5 shadow-sm">
          <h3 className="text-lg font-bold text-stone-900 mb-6">Recent Activity</h3>
          <div className="space-y-4">
            {progress.length > 0 ? (
              progress.slice(0, 5).map((p, i) => (
                <div key={p.id} className="flex items-center justify-between p-4 rounded-2xl bg-stone-50">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm">
                      {p.type === 'quiz' ? (
                        <BrainCircuit className="w-5 h-5 text-emerald-600" />
                      ) : (
                        <Layers className="w-5 h-5 text-blue-600" />
                      )}
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-stone-900">
                        {p.type === 'quiz' ? 'Quiz Completed' : 'Flashcards Reviewed'}
                      </p>
                      <p className="text-xs text-stone-500">{new Date(p.timestamp).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-stone-900">
                      {p.type === 'quiz' ? `${p.score}/${p.totalQuestions}` : `${p.totalQuestions} Cards`}
                    </p>
                    <p className={cn(
                      "text-xs font-medium",
                      p.type === 'quiz' ? "text-emerald-600" : "text-blue-600"
                    )}>
                      {p.type === 'quiz' ? `${Math.round((p.score/p.totalQuestions)*100)}%` : 'Completed'}
                    </p>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12 text-stone-400">
                No recent activity found.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, sublabel }: { icon: React.ReactNode, label: string, value: string | number, sublabel: string }) {
  return (
    <div className="bg-white p-6 rounded-3xl border border-black/5 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <div className="w-12 h-12 bg-stone-50 rounded-2xl flex items-center justify-center">
          {icon}
        </div>
      </div>
      <p className="text-sm font-medium text-stone-500 mb-1">{label}</p>
      <h4 className="text-2xl font-bold text-stone-900 mb-1">{value}</h4>
      <p className="text-xs text-stone-400">{sublabel}</p>
    </div>
  );
}
