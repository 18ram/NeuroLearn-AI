import { DocumentMetadata } from '../types';
import { ArrowLeft, BrainCircuit, Layers, FileText, Play, Volume2, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import { useState } from 'react';

interface SummaryViewProps {
  doc: DocumentMetadata;
  onBack: () => void;
  onStartQuiz: () => void;
  onStartFlashcards: () => void;
}

export default function SummaryView({ doc, onBack, onStartQuiz, onStartFlashcards }: SummaryViewProps) {
  const [isSpeaking, setIsSpeaking] = useState(false);

  const handleSpeak = () => {
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    const utterance = new SpeechSynthesisUtterance(doc.summary);
    utterance.onend = () => setIsSpeaking(false);
    window.speechSynthesis.speak(utterance);
    setIsSpeaking(true);
  };

  return (
    <div className="space-y-8">
      <button 
        onClick={onBack}
        className="flex items-center gap-2 text-stone-500 hover:text-stone-900 transition-colors font-medium"
      >
        <ArrowLeft className="w-5 h-5" />
        Back to Documents
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white p-10 rounded-3xl border border-black/5 shadow-sm">
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center">
                  <FileText className="w-6 h-6 text-emerald-600" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-stone-900 tracking-tight">{doc.title}</h3>
                  <p className="text-sm text-stone-500">AI-Generated Summary</p>
                </div>
              </div>
              <button 
                onClick={handleSpeak}
                className={`p-3 rounded-2xl transition-all ${isSpeaking ? 'bg-emerald-600 text-white' : 'bg-stone-50 text-stone-600 hover:bg-stone-100'}`}
              >
                <Volume2 className="w-6 h-6" />
              </button>
            </div>

            <div className="prose prose-stone max-w-none prose-headings:font-bold prose-headings:tracking-tight prose-p:text-stone-600 prose-li:text-stone-600 mb-10">
              <ReactMarkdown>{doc.summary}</ReactMarkdown>
            </div>

            {doc.keyTerms && doc.keyTerms.length > 0 && (
              <div className="pt-8 border-t border-stone-100">
                <h4 className="text-lg font-bold text-stone-900 mb-4 flex items-center gap-2">
                  <BrainCircuit className="w-5 h-5 text-emerald-600" />
                  Key Terms & Concepts
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {doc.keyTerms.map((term, i) => (
                    <div key={i} className="p-4 rounded-2xl bg-stone-50 border border-stone-100 text-sm text-stone-700">
                      {term}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white p-8 rounded-3xl border border-black/5 shadow-sm">
            <h4 className="font-bold text-stone-900 mb-6">Learning Actions</h4>
            <div className="space-y-4">
              <ActionButton 
                icon={<BrainCircuit className="text-emerald-600" />} 
                label="Take a Quiz" 
                description="Test your knowledge with AI-generated questions."
                onClick={onStartQuiz}
              />
              <ActionButton 
                icon={<Layers className="text-blue-600" />} 
                label="Study Flashcards" 
                description="Master key concepts with spaced repetition."
                onClick={onStartFlashcards}
              />
            </div>
          </div>

          <div className="bg-emerald-900 p-8 rounded-3xl text-white shadow-lg relative overflow-hidden">
            <div className="relative z-10">
              <h4 className="font-bold mb-2">Pro Tip</h4>
              <p className="text-emerald-100 text-sm leading-relaxed">
                Reviewing the summary before taking a quiz can improve your score by up to 40%.
              </p>
            </div>
            <div className="absolute -right-4 -bottom-4 opacity-10">
              <BrainCircuit className="w-32 h-32" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ActionButton({ icon, label, description, onClick }: { icon: React.ReactNode, label: string, description: string, onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="w-full flex items-start gap-4 p-4 rounded-2xl bg-stone-50 hover:bg-stone-100 transition-all text-left group"
    >
      <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
        {icon}
      </div>
      <div>
        <p className="text-sm font-bold text-stone-900 mb-1">{label}</p>
        <p className="text-xs text-stone-500 leading-relaxed">{description}</p>
      </div>
    </button>
  );
}
