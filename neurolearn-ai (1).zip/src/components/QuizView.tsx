import { useState, useEffect } from 'react';
import { collection, addDoc, getDocs, query, where, limit } from 'firebase/firestore';
import { db, auth } from '../firebase';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}
import { DocumentMetadata, Quiz, QuizQuestion, Progress } from '../types';
import { generateQuiz } from '../services/gemini';
import { 
  BrainCircuit, 
  Loader2, 
  CheckCircle2, 
  XCircle, 
  ArrowRight, 
  ArrowLeft,
  Trophy,
  AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface QuizViewProps {
  doc: DocumentMetadata;
  userId: string;
  onComplete: () => void;
  onBack: () => void;
}

export default function QuizView({ doc: document, userId, onComplete, onBack }: QuizViewProps) {
  const [loading, setLoading] = useState(true);
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');

  useEffect(() => {
    const fetchOrCreateQuiz = async () => {
      setLoading(true);
      try {
        // Check if a quiz already exists for this document and difficulty
        const quizzesRef = collection(db, 'users', userId, 'documents', document.id, 'quizzes');
        const q = query(quizzesRef, where('difficulty', '==', difficulty), limit(1));
        const snapshot = await getDocs(q);

        if (!snapshot.empty) {
          const quizData = snapshot.docs[0].data() as Quiz;
          setQuiz({ ...quizData, id: snapshot.docs[0].id });
        } else {
          // Generate new quiz with AI
          const questions = await generateQuiz(document.content, difficulty);
          const newQuiz: Omit<Quiz, 'id'> = {
            questions,
            difficulty,
            createdAt: new Date().toISOString(),
          };
          const docRef = await addDoc(quizzesRef, newQuiz);
          setQuiz({ ...newQuiz, id: docRef.id });
        }
      } catch (error) {
        console.error('Quiz generation failed:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchOrCreateQuiz();
  }, [document.id, difficulty, userId]);

  const handleAnswerSelect = (answer: string) => {
    if (showResult) return;
    setSelectedAnswer(answer);
    setShowResult(true);
    
    if (answer === quiz?.questions[currentQuestionIndex].correctAnswer) {
      setScore(prev => prev + 1);
    }
  };

  const handleNextQuestion = async () => {
    if (!quiz) return;

    if (currentQuestionIndex < quiz.questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      setQuizFinished(true);
      // Save progress to Firestore
      const path = `users/${userId}/progress`;
      try {
        await addDoc(collection(db, 'users', userId, 'progress'), {
          type: 'quiz',
          docId: document.id,
          quizId: quiz.id,
          score: score,
          totalQuestions: quiz.questions.length,
          timestamp: new Date().toISOString(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, path);
      }
    }
  };

  if (loading) {
    return (
      <div className="min-h-[400px] flex flex-col items-center justify-center bg-white rounded-3xl border border-black/5 shadow-sm">
        <Loader2 className="w-10 h-10 animate-spin text-emerald-600 mb-4" />
        <p className="text-stone-600 font-medium">AI is crafting your quiz...</p>
      </div>
    );
  }

  if (!quiz) {
    return (
      <div className="min-h-[400px] flex flex-col items-center justify-center bg-white rounded-3xl border border-black/5 shadow-sm">
        <AlertCircle className="w-10 h-10 text-red-500 mb-4" />
        <p className="text-stone-600 font-medium">Failed to load quiz. Please try again.</p>
        <button onClick={onBack} className="mt-4 text-emerald-600 font-bold">Go Back</button>
      </div>
    );
  }

  if (quizFinished) {
    const finalScore = score;
    const percentage = Math.round((finalScore / quiz.questions.length) * 100);

    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-2xl mx-auto bg-white p-12 rounded-3xl border border-black/5 shadow-xl text-center"
      >
        <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <Trophy className="w-10 h-10 text-emerald-600" />
        </div>
        <h3 className="text-3xl font-bold text-stone-900 mb-2">Quiz Completed!</h3>
        <p className="text-stone-500 mb-8">You've mastered another session. Great job!</p>
        
        <div className="grid grid-cols-2 gap-6 mb-10">
          <div className="bg-stone-50 p-6 rounded-2xl">
            <p className="text-sm text-stone-500 mb-1">Score</p>
            <p className="text-3xl font-bold text-stone-900">{finalScore} / {quiz.questions.length}</p>
          </div>
          <div className="bg-stone-50 p-6 rounded-2xl">
            <p className="text-sm text-stone-500 mb-1">Accuracy</p>
            <p className="text-3xl font-bold text-stone-900">{percentage}%</p>
          </div>
        </div>

        <button 
          onClick={onComplete}
          className="w-full py-4 bg-stone-900 text-white rounded-2xl font-bold hover:bg-stone-800 transition-colors shadow-lg"
        >
          Return to Dashboard
        </button>
      </motion.div>
    );
  }

  const currentQuestion = quiz.questions[currentQuestionIndex];

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <button onClick={onBack} className="flex items-center gap-2 text-stone-500 hover:text-stone-900 transition-colors font-medium">
          <ArrowLeft className="w-5 h-5" />
          Quit Quiz
        </button>
        <div className="flex items-center gap-4">
          <div className="px-4 py-1.5 bg-stone-100 text-stone-600 rounded-full text-xs font-bold uppercase tracking-wider">
            {difficulty}
          </div>
          <div className="text-sm font-bold text-stone-400">
            Question {currentQuestionIndex + 1} of {quiz.questions.length}
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="h-2 bg-stone-100 rounded-full overflow-hidden">
        <motion.div 
          className="h-full bg-emerald-500"
          initial={{ width: 0 }}
          animate={{ width: `${((currentQuestionIndex + 1) / quiz.questions.length) * 100}%` }}
        />
      </div>

      <motion.div 
        key={currentQuestionIndex}
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        className="bg-white p-10 rounded-3xl border border-black/5 shadow-sm"
      >
        <h3 className="text-2xl font-bold text-stone-900 mb-8 leading-tight">
          {currentQuestion.question}
        </h3>

        <div className="space-y-4">
          {currentQuestion.options?.map((option, index) => {
            const isSelected = selectedAnswer === option;
            const isCorrect = option === currentQuestion.correctAnswer;
            const isWrong = isSelected && !isCorrect;

            return (
              <button
                key={index}
                disabled={showResult}
                onClick={() => handleAnswerSelect(option)}
                className={cn(
                  "w-full p-5 rounded-2xl text-left font-medium transition-all border-2 flex items-center justify-between group",
                  !showResult && "border-stone-100 hover:border-emerald-500 hover:bg-emerald-50/30",
                  showResult && isCorrect && "border-emerald-500 bg-emerald-50 text-emerald-700",
                  showResult && isWrong && "border-red-500 bg-red-50 text-red-700",
                  showResult && !isCorrect && !isWrong && "border-stone-100 opacity-50"
                )}
              >
                <span className="flex-1">{option}</span>
                {showResult && isCorrect && <CheckCircle2 className="w-6 h-6 text-emerald-600" />}
                {showResult && isWrong && <XCircle className="w-6 h-6 text-red-600" />}
              </button>
            );
          })}
        </div>

        <AnimatePresence>
          {showResult && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="mt-8 pt-8 border-t border-stone-100"
            >
              <div className={cn(
                "p-4 rounded-2xl flex items-center gap-3 mb-6",
                selectedAnswer === currentQuestion.correctAnswer ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"
              )}>
                {selectedAnswer === currentQuestion.correctAnswer ? (
                  <>
                    <CheckCircle2 className="w-5 h-5" />
                    <span className="font-bold">Correct!</span>
                  </>
                ) : (
                  <>
                    <XCircle className="w-5 h-5" />
                    <span className="font-bold">Incorrect. The correct answer is: {currentQuestion.correctAnswer}</span>
                  </>
                )}
              </div>
              <button
                onClick={handleNextQuestion}
                className="w-full py-4 bg-stone-900 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-stone-800 transition-colors"
              >
                {currentQuestionIndex === quiz.questions.length - 1 ? 'Finish Quiz' : 'Next Question'}
                <ArrowRight className="w-5 h-5" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
