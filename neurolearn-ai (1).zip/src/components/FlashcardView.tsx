import { useState, useEffect } from 'react';
import { collection, addDoc, getDocs, query, limit } from 'firebase/firestore';
import { db, auth } from '../firebase';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}
import { DocumentMetadata, Flashcard } from '../types';
import { generateFlashcards } from '../services/gemini';
import { 
  Layers, 
  Loader2, 
  ArrowLeft, 
  ArrowRight, 
  RotateCw, 
  CheckCircle2, 
  AlertCircle,
  Trophy
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface FlashcardViewProps {
  doc: DocumentMetadata;
  userId: string;
  onBack: () => void;
}

export default function FlashcardView({ doc: document, userId, onBack }: FlashcardViewProps) {
  const [loading, setLoading] = useState(true);
  const [cards, setCards] = useState<Flashcard[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [studyFinished, setStudyFinished] = useState(false);

  useEffect(() => {
    const fetchOrCreateCards = async () => {
      setLoading(true);
      try {
        const cardsRef = collection(db, 'users', userId, 'documents', document.id, 'flashcards');
        const snapshot = await getDocs(query(cardsRef, limit(20)));

        if (!snapshot.empty) {
          setCards(snapshot.docs.map(d => ({ ...d.data(), id: d.id } as Flashcard)));
        } else {
          const generatedCards = await generateFlashcards(document.content);
          const newCards = generatedCards.map((c: any) => ({
            ...c,
            nextReview: new Date().toISOString(),
            interval: 1,
            easeFactor: 2.5,
          }));
          
          const savedCards: Flashcard[] = [];
          for (const card of newCards) {
            const docRef = await addDoc(cardsRef, card);
            savedCards.push({ ...card, id: docRef.id });
          }
          setCards(savedCards);
        }
      } catch (error) {
        console.error('Flashcard generation failed:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchOrCreateCards();
  }, [document.id, userId]);

  const handleNext = async () => {
    if (currentIndex < cards.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setIsFlipped(false);
    } else {
      setStudyFinished(true);
      // Save progress to Firestore
      const path = `users/${userId}/progress`;
      try {
        await addDoc(collection(db, 'users', userId, 'progress'), {
          type: 'flashcards',
          docId: document.id,
          score: cards.length, // For flashcards, score is number of cards reviewed
          totalQuestions: cards.length,
          timestamp: new Date().toISOString(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, path);
      }
    }
  };

  const handlePrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
      setIsFlipped(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-[400px] flex flex-col items-center justify-center bg-white rounded-3xl border border-black/5 shadow-sm">
        <Loader2 className="w-10 h-10 animate-spin text-blue-600 mb-4" />
        <p className="text-stone-600 font-medium">AI is generating your flashcards...</p>
      </div>
    );
  }

  if (cards.length === 0) {
    return (
      <div className="min-h-[400px] flex flex-col items-center justify-center bg-white rounded-3xl border border-black/5 shadow-sm">
        <AlertCircle className="w-10 h-10 text-red-500 mb-4" />
        <p className="text-stone-600 font-medium">Failed to load flashcards. Please try again.</p>
        <button onClick={onBack} className="mt-4 text-blue-600 font-bold">Go Back</button>
      </div>
    );
  }

  if (studyFinished) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-2xl mx-auto bg-white p-12 rounded-3xl border border-black/5 shadow-xl text-center"
      >
        <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 className="w-10 h-10 text-blue-600" />
        </div>
        <h3 className="text-3xl font-bold text-stone-900 mb-2">Session Complete!</h3>
        <p className="text-stone-500 mb-8">You've reviewed all {cards.length} flashcards. Keep it up!</p>
        <button 
          onClick={onBack}
          className="w-full py-4 bg-stone-900 text-white rounded-2xl font-bold hover:bg-stone-800 transition-colors shadow-lg"
        >
          Back to Documents
        </button>
      </motion.div>
    );
  }

  const currentCard = cards[currentIndex];

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <button onClick={onBack} className="flex items-center gap-2 text-stone-500 hover:text-stone-900 transition-colors font-medium">
          <ArrowLeft className="w-5 h-5" />
          Stop Studying
        </button>
        <div className="text-sm font-bold text-stone-400">
          Card {currentIndex + 1} of {cards.length}
        </div>
      </div>

      {/* Progress Bar */}
      <div className="h-2 bg-stone-100 rounded-full overflow-hidden">
        <motion.div 
          className="h-full bg-blue-500"
          initial={{ width: 0 }}
          animate={{ width: `${((currentIndex + 1) / cards.length) * 100}%` }}
        />
      </div>

      <div className="perspective-1000 h-[400px] relative group">
        <motion.div
          animate={{ rotateY: isFlipped ? 180 : 0 }}
          transition={{ duration: 0.6, type: 'spring', stiffness: 260, damping: 20 }}
          className="w-full h-full relative preserve-3d cursor-pointer"
          onClick={() => setIsFlipped(!isFlipped)}
        >
          {/* Front */}
          <div className="absolute inset-0 backface-hidden bg-white p-12 rounded-3xl border border-black/5 shadow-xl flex flex-col items-center justify-center text-center">
            <p className="text-xs font-bold text-blue-500 uppercase tracking-widest mb-6">Front</p>
            <h3 className="text-2xl font-bold text-stone-900 leading-tight">
              {currentCard.front}
            </h3>
            <div className="mt-12 flex items-center gap-2 text-stone-400 text-sm font-medium">
              <RotateCw className="w-4 h-4" />
              Click to flip
            </div>
          </div>

          {/* Back */}
          <div 
            className="absolute inset-0 backface-hidden bg-blue-50 p-12 rounded-3xl border border-blue-100 shadow-xl flex flex-col items-center justify-center text-center"
            style={{ transform: 'rotateY(180deg)' }}
          >
            <p className="text-xs font-bold text-blue-500 uppercase tracking-widest mb-6">Back</p>
            <h3 className="text-2xl font-bold text-stone-900 leading-tight">
              {currentCard.back}
            </h3>
            <div className="mt-12 flex items-center gap-2 text-blue-400 text-sm font-medium">
              <RotateCw className="w-4 h-4" />
              Click to flip
            </div>
          </div>
        </motion.div>
      </div>

      <div className="flex items-center justify-between gap-4">
        <button
          onClick={handlePrevious}
          disabled={currentIndex === 0}
          className="flex-1 py-4 bg-white text-stone-600 rounded-2xl font-bold border border-black/5 hover:bg-stone-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Previous
        </button>
        <button
          onClick={handleNext}
          className="flex-[2] py-4 bg-stone-900 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-stone-800 transition-colors"
        >
          {currentIndex === cards.length - 1 ? 'Finish Session' : 'Next Card'}
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
