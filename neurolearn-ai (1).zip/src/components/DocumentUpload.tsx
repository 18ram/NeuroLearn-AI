import { useState, useRef } from 'react';
import { collection, addDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { generateSummary, generateKeyTerms } from '../services/gemini';
import { Upload, FileText, Loader2, CheckCircle2, AlertCircle } from 'lucide-react';
import * as pdfjsLib from 'pdfjs-dist';

// Import the worker as a URL using Vite's ?url suffix
import pdfWorker from 'pdfjs-dist/build/pdf.worker.min.mjs?url';

// Set worker source
pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker;

interface DocumentUploadProps {
  userId: string;
}

export default function DocumentUpload({ userId }: DocumentUploadProps) {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const extractTextFromPDF = async (file: File): Promise<string> => {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    let fullText = '';
    
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items.map((item: any) => item.str).join(' ');
      fullText += pageText + '\n';
    }
    
    return fullText;
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setError(null);
    setSuccess(false);

    try {
      let content = '';
      if (file.type === 'application/pdf') {
        content = await extractTextFromPDF(file);
      } else if (file.type === 'text/plain') {
        content = await file.text();
      } else {
        throw new Error('Unsupported file format. Please upload PDF or TXT.');
      }

      if (content.trim().length < 50) {
        throw new Error('Document content is too short to analyze.');
      }

      // Generate AI Summary and Key Terms
      const [summary, keyTerms] = await Promise.all([
        generateSummary(content),
        generateKeyTerms(content)
      ]);

      // Save to Firestore
      await addDoc(collection(db, 'users', userId, 'documents'), {
        title: file.name,
        content: content,
        summary: summary,
        keyTerms: keyTerms,
        createdAt: new Date().toISOString(),
      });

      setSuccess(true);
      if (fileInputRef.current) fileInputRef.current.value = '';
    } catch (err: any) {
      console.error('Upload error:', err);
      setError(err.message || 'Failed to process document.');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="bg-white p-8 rounded-3xl border border-black/5 shadow-sm">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-bold text-stone-900">Upload Document</h3>
          <p className="text-sm text-stone-500">Add PDFs or text files to generate quizzes and flashcards.</p>
        </div>
        <FileText className="w-8 h-8 text-stone-200" />
      </div>

      <div 
        onClick={() => fileInputRef.current?.click()}
        className={`
          border-2 border-dashed rounded-2xl p-10 text-center cursor-pointer transition-all
          ${uploading ? 'bg-stone-50 border-stone-200 pointer-events-none' : 'hover:bg-stone-50 border-stone-200 hover:border-emerald-500'}
        `}
      >
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleFileUpload} 
          accept=".pdf,.txt" 
          className="hidden" 
        />
        
        {uploading ? (
          <div className="flex flex-col items-center gap-4">
            <Loader2 className="w-10 h-10 animate-spin text-emerald-600" />
            <p className="text-sm font-medium text-stone-600">Analyzing document with AI...</p>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-4">
            <div className="w-12 h-12 bg-emerald-50 rounded-full flex items-center justify-center">
              <Upload className="w-6 h-6 text-emerald-600" />
            </div>
            <div>
              <p className="text-sm font-bold text-stone-900 mb-1">Click to upload or drag and drop</p>
              <p className="text-xs text-stone-400">PDF or TXT (Max 10MB)</p>
            </div>
          </div>
        )}
      </div>

      {error && (
        <div className="mt-4 p-4 bg-red-50 text-red-700 rounded-xl flex items-center gap-3 text-sm">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          {error}
        </div>
      )}

      {success && (
        <div className="mt-4 p-4 bg-emerald-50 text-emerald-700 rounded-xl flex items-center gap-3 text-sm">
          <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
          Document uploaded and analyzed successfully!
        </div>
      )}
    </div>
  );
}
